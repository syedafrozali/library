export default {
  region: '',
  UserPoolId: '',
  ClientId: '',
}
